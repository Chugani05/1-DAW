# ********************
# INTERVALO DESPLEGADO
# ********************


def run(interval: str) -> list:
    irange = []

    match interval:
        case '[]':
            irange = range(0,-1)
        case '(]':
            irange = range(1:)
        case '[)':
            irange = range(:-2)
        case '()':
            irange = range(1:-2)

    return irange


if __name__ == '__main__':
    run('[3,10]')
