# ********************************
# ENUMERANDO ELEMENTOS MODO HUMANO
# ********************************


def run(items: str) -> str:
    enum_items = []

    spliting_items = items.split(':')
    replacing_items = ', '.join(spliting_items)
    reversing_items = replacing_items[::-1]
    replacing_items2 = reversing_items.replace(' ,', ' dna ', 1)
    enum_items = replacing_items2[::-1]

    return enum_items


if __name__ == '__main__':
    run('apples')
