# ***************************
# BUSCANDO LA MAYOR DISTANCIA
# ***************************


def run(values: list, target: int) -> int:
    max_diff = 0
    if values == []:
        max_diff = 0
    elif value in values:
        target == value:
        max_diff = 0
    else:
        for value in values:
            target - int(value):
            max_diff.append()

    return max_diff


if __name__ == '__main__':
    run([7, 3, 1, 12, 21, 4], 8)
