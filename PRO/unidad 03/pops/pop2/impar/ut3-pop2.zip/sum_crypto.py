# ******************
# SUMA CRIPTOGRÁFICA
# ******************
from pathlib import Path


def run(crypto_path: Path) -> float:
    with open(crypto_path, 'r') as f:
        for line in f:
            clear_lines = line.strip()
            values =
            sum += values
    sum_cr = 

    return sum_cr


if __name__ == '__main__':
    run('data/sum_crypto/data1.crypto')